EECS 3431 ASSIGHNMENT 1

ALL TASKS COMPLETED
a) All animations are synchronised with TIME
b) A ground box was drawn
c) Two rocks drawn
d) 3 seaweed strands drawn each consisting of 10 ellipses
e) seaweed animated
f) 3 strands positioned on the rocks
g) fish model created, consisting of 2 eyes with pupils, head, body and 2 tail fins
h) fish swims on the tangent of a circle around the seaweed
i) a burst of 4 or 5 bubbles occur.
j) each bubble spawns on the mouth of the human model
k) The shape/ size of each bubble ocillates with time
l) each bubble moves straight upwards with time
m) each bubble is removed 12 seconds after being spawned/blown
n) model created of hum character without arms
o) character moves on the XY axis only
p) The character model kicks, the feet do not rotate
q) scene is very similar in comparison to the example provided in terms of motion and shapes
s) scene is 512X512 in size